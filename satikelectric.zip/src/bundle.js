window.$ = require('jquery');
window._ = require('lodash');
window.bootstrap = require('bootstrap');