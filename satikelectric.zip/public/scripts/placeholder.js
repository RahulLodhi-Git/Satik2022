// Variables
const SOME_CONSTANT = 5;
let someVariable = 'string WITH SINGLE QUOTES';
let someString = `template string if using '' is needed`;

// Functions
function someFunction(someParam) {

}

// Requires jQuery
$('#someBtn').click((event) => {
    console.log($(event.currentTarget));
});